Download the exam file(s) and solve each of the problems to the best of your ability. When finished upload a zip archive containing your solution files.

Notes:
You do NOT need to create a video demo for this exam.
To prevent other students from copying your work, please make sure your code is not saved on GitHub or any file-sharing site.
If you are having trouble uploading files on the Exam App, please let your instructor know.