console.log("I got a rainbow!");
console.log("And an extension called Indent Rainbow");
console.log("I got Intelligence!");
console.log("And an extension called Intellicode");