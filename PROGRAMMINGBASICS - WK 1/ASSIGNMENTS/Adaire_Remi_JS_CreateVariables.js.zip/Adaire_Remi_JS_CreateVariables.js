var RideBasics =  "All Riders Must Meet the Minimum Requirements of 10 Years Old and 42 Inches Tall"; 
console.log(RideBasics)
// I chose a String as the Variable