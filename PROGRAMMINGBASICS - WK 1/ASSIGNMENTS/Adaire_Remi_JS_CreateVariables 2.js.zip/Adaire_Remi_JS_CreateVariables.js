
var permission = "Get on that ride, kiddo!"
var noPermission = "Sorry kiddo. Maybe next year."
var num1 = 42
var num3 = 10
if (num1 >= 42) {
    console.log(permission)
}
else {
    console.log(noPermission)
}

// Stretch condition includes 10 years old and 42 inches 
if (num1 >= 42) {
    if (num3 >= 10) {
        console.log(permission)
    } else {
        console.log(noPermission)
    }
}
else {
    console.log(noPermission)
}
