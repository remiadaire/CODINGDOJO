// likeCount is meant to track the number of likes
var likeCount = 0;
// increaseLikes is meant to track new likes
function increaseLikes() {
    // is meant to add starting point of 0 and track every new like
    likeCount = likeCount + 1;
}
